#This file writed by alirezaahani :)
from distutils.core import setup

setup(name='QtPastebin',
      version='0.1',
      description='A gui for ubuntu.ir pastebin',
      author='Alireza Ahani',
      author_email='alirezaahani@protonmail.com',
      url='https://github.com/alirezaahani/Unoffcial-gui-for-ubuntu-pastebin',
      packages=['ui'],
      install_requires=["pyqt5","requests"],
      license='GPLv3',
      long_description=open('README.txt').read()
     )
