#This file writed by alirezaahani :)
from setuptools import find_packages, setup
setup(
    name="qt-pastebin",
    packages=find_packages(),
    version="0.1",
    license="GPLv3",
    long_description=open('README.txt').read(),
    install_requires=['pyqt5','requests'],
    author="Alireza Ahani",
    author_email="alirezaahani@protonmail.com",
    url="https://github.com/alirezaahani/Unoffcial-gui-for-ubuntu-pastebin",
    description="A gui writed with qt and python3 for ubuntu.ir pastebin.",
)
