# Unoffcial-gui-for-ubuntu-pastebin
A gui writed with qt and python3 for ubuntu.ir pastebin.  
## Installation
You need to install pyqt5 and requests library using this command:  
```
pip install pyqt5 requests 
```  
After installing the librarys ,you can run the while you are in main folder of program using this command:  
```
python3 src/main.py
```
Put your texts in it and share the link.  
